//increase alphas and activation fractions
//to do: implement activation fraction in trigger
class gameLogicSettingUp extends gameLogic{
     constructor(parent) {
          super(parent)
     }
     trigger(type) {
          if (type === "step") {
               //adjust RBG elements bit by bit, test later                              
               let sun = this.figures.sun.entity
               sun.movementFraction = Math.max(0.11, sun.movementFraction - 0.0075)
                     
               //up alpha to bring out background elements
               customObjectForEachAndFilter(this.figures,
                    (figure) => figure.background === true,
                    (key, figure) => figure.alpha += 0.045
               )
          }
     }
     draw(ctx) {
          this.parent.drawFigures(ctx, true, false)
     }
}